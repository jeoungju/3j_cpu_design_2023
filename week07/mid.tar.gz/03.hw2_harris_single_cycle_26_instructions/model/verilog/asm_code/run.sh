java -jar ./rars1_6.jar
